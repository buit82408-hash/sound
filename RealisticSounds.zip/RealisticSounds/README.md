# Realistic Sounds (Fabric, Minecraft 1.21.11)

Mod client giúp âm thanh Minecraft chân thật hơn.

## Tính năng (đã có trong code)
- **Che chắn âm thanh**: có tường/khối rắn giữa bạn và nguồn âm thì âm nhỏ và hơi trầm đi.
- **Hấp thụ theo khoảng cách**: âm xa mất dần độ rõ.
- **Dưới nước**: mọi âm thanh bị nghẹt (nhỏ hơn, trầm hơn).
- Cấu hình ở `config/realisticsounds.json` (tự tạo khi chạy lần đầu).

## Chưa có
- Vang (reverb) trong hang và bộ lọc low-pass thật. Cần can thiệp OpenAL EFX, làm ở bản sau.
- Bộ âm thanh thu thật. Mod không kèm file âm thanh, bạn tự thêm (xem bên dưới).

## Thay file âm thanh
Đặt file `.ogg` (mono, 44.1 kHz) vào `src/main/resources/assets/minecraft/sounds/` với **đúng đường dẫn và tên như bản gốc**, ví dụ:

```
src/main/resources/assets/minecraft/sounds/step/stone1.ogg
src/main/resources/assets/minecraft/sounds/dig/grass1.ogg
```

Tài nguyên của mod được nạp đè lên tài nguyên gốc. Chỉ dùng file bạn có quyền sử dụng (tự thu, CC0, hoặc đúng giấy phép). Chuyển định dạng:

```
ffmpeg -i input.wav -ac 1 -ar 44100 -c:a libvorbis -q:a 5 output.ogg
```

## Build trên GitHub
1. Tạo repo mới trên GitHub, upload toàn bộ nội dung thư mục này (giữ nguyên `.github/workflows/build.yml`).
2. Vào tab **Actions**, workflow **Build** chạy tự động. Xong thì tải file `.jar` ở mục Artifacts.
3. Muốn tạo Release: gắn tag `v1.0.0` rồi push, jar sẽ tự đính kèm vào Release.

Build cục bộ: cài JDK 21 và Gradle 9.2.1, chạy `gradle build`, jar nằm ở `build/libs/`.

## Lưu ý phiên bản
Phiên bản Loom, Yarn, Fabric Loader trong `gradle.properties` lấy theo thông tin công bố cho 1.21.11. Nếu build báo không tìm thấy phiên bản nào, đối chiếu lại tại https://fabricmc.net/develop và sửa cho khớp.
