package com.realisticsounds;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RealisticSoundsClient implements ClientModInitializer {
    public static final String MOD_ID = "realisticsounds";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        RealisticConfig.load();
        LOGGER.info("Realistic Sounds đã tải (enabled={})", RealisticConfig.get().enabled);
    }
}
