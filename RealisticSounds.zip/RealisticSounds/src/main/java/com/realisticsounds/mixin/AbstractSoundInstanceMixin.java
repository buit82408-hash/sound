package com.realisticsounds.mixin;

import com.realisticsounds.RealisticConfig;
import com.realisticsounds.SoundEnvironment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.AbstractSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Chặn getVolume()/getPitch() của mọi SoundInstance để nhân thêm hệ số môi trường.
 * Kết quả được cache vài tick để không phải dò khối liên tục.
 */
@Mixin(AbstractSoundInstance.class)
public abstract class AbstractSoundInstanceMixin {
    @Unique
    private long realisticsounds$lastCalc = Long.MIN_VALUE;
    @Unique
    private float realisticsounds$volMul = 1.0f;
    @Unique
    private float realisticsounds$pitchMul = 1.0f;

    @Unique
    private void realisticsounds$refresh() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) {
            realisticsounds$volMul = 1.0f;
            realisticsounds$pitchMul = 1.0f;
            return;
        }
        long now = mc.world.getTime();
        long age = now - realisticsounds$lastCalc;
        if (age >= 0 && age < Math.max(1, RealisticConfig.get().recalcTicks)) {
            return;
        }
        realisticsounds$lastCalc = now;
        float[] r = SoundEnvironment.compute((SoundInstance) (Object) this);
        realisticsounds$volMul = r[0];
        realisticsounds$pitchMul = r[1];
    }

    @Inject(method = "getVolume", at = @At("RETURN"), cancellable = true)
    private void realisticsounds$volume(CallbackInfoReturnable<Float> cir) {
        realisticsounds$refresh();
        cir.setReturnValue(cir.getReturnValueF() * realisticsounds$volMul);
    }

    @Inject(method = "getPitch", at = @At("RETURN"), cancellable = true)
    private void realisticsounds$pitch(CallbackInfoReturnable<Float> cir) {
        realisticsounds$refresh();
        cir.setReturnValue(cir.getReturnValueF() * realisticsounds$pitchMul);
    }
}
