package com.realisticsounds;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Cấu hình lưu tại config/realisticsounds.json. Sửa file rồi khởi động lại game.
 */
public class RealisticConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static RealisticConfig instance = new RealisticConfig();

    /** Bật/tắt toàn bộ hiệu ứng. */
    public boolean enabled = true;

    /** Âm thanh bị nhỏ đi khi có khối rắn nằm giữa bạn và nguồn âm. */
    public boolean occlusion = true;
    /** Mỗi khối rắn chắn giữa làm giảm bao nhiêu âm lượng (0..1). */
    public float occlusionPerBlock = 0.12f;
    /** Mức giảm tối đa do che chắn (0..1). */
    public float occlusionMax = 0.75f;
    /** Âm bị che chắn sẽ trầm đi một chút (0 = tắt). */
    public float occlusionPitchDrop = 0.05f;

    /** Âm xa mất dần độ vang rõ: giảm thêm tối đa bao nhiêu ở khoảng cách 48 khối (0 = tắt). */
    public float airAbsorption = 0.15f;

    /** Khi người chơi chìm dưới nước: hệ số âm lượng và cao độ. */
    public boolean underwaterMuffle = true;
    public float underwaterVolume = 0.55f;
    public float underwaterPitch = 0.92f;

    /** Số tick giữa hai lần tính lại che chắn cho một nguồn âm (giảm tải CPU). */
    public int recalcTicks = 3;

    public static RealisticConfig get() {
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("realisticsounds.json");
    }

    public static void load() {
        Path p = path();
        try {
            if (Files.exists(p)) {
                String json = Files.readString(p, StandardCharsets.UTF_8);
                RealisticConfig loaded = GSON.fromJson(json, RealisticConfig.class);
                if (loaded != null) {
                    instance = loaded;
                }
            }
            // Ghi lại để bổ sung các trường mới nếu có
            Files.createDirectories(p.getParent());
            Files.writeString(p, GSON.toJson(instance), StandardCharsets.UTF_8);
        } catch (IOException | RuntimeException e) {
            RealisticSoundsClient.LOGGER.warn("Không đọc/ghi được config, dùng mặc định", e);
            instance = new RealisticConfig();
        }
    }
}
