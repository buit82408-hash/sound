package com.realisticsounds;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Tính hệ số âm lượng và cao độ cho một nguồn âm dựa trên môi trường quanh người chơi.
 */
public final class SoundEnvironment {
    public static final float[] NEUTRAL = {1.0f, 1.0f};

    private SoundEnvironment() {
    }

    /** @return {hệ số âm lượng, hệ số cao độ} */
    public static float[] compute(SoundInstance sound) {
        RealisticConfig cfg = RealisticConfig.get();
        if (!cfg.enabled) {
            return NEUTRAL;
        }

        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = mc.world;
        ClientPlayerEntity player = mc.player;
        if (world == null || player == null) {
            return NEUTRAL;
        }

        // Không đụng vào nhạc nền, đĩa nhạc, giọng nói, UI (âm không có vị trí)
        SoundCategory cat = sound.getCategory();
        if (cat == SoundCategory.MASTER || cat == SoundCategory.MUSIC
                || cat == SoundCategory.RECORDS || cat == SoundCategory.VOICE
                || sound.isRelative()) {
            return NEUTRAL;
        }

        float vol = 1.0f;
        float pitch = 1.0f;

        Vec3d ear = player.getEyePos();
        Vec3d src = new Vec3d(sound.getX(), sound.getY(), sound.getZ());
        double dist = ear.distanceTo(src);

        // 1) Hấp thụ không khí: âm xa yếu hơn một chút ngoài mức suy giảm mặc định
        if (cfg.airAbsorption > 0.0f) {
            double t = MathHelper.clamp(dist / 48.0, 0.0, 1.0);
            vol *= (float) (1.0 - cfg.airAbsorption * t);
        }

        // 2) Che chắn: đếm số khối rắn nằm trên đường thẳng từ tai đến nguồn âm
        if (cfg.occlusion && dist > 1.5) {
            int solid = countSolidBlocks(world, ear, src, dist);
            if (solid > 0) {
                float occ = Math.min(cfg.occlusionMax, solid * cfg.occlusionPerBlock);
                vol *= (1.0f - occ);
                pitch *= (1.0f - cfg.occlusionPitchDrop * occ);
            }
        }

        // 3) Dưới nước: âm bị nghẹt
        if (cfg.underwaterMuffle && player.isSubmergedInWater()) {
            vol *= cfg.underwaterVolume;
            pitch *= cfg.underwaterPitch;
        }

        return new float[]{vol, pitch};
    }

    private static int countSolidBlocks(ClientWorld world, Vec3d from, Vec3d to, double dist) {
        int steps = (int) Math.min(48, Math.ceil(dist * 1.5));
        if (steps < 2) {
            return 0;
        }

        BlockPos earPos = BlockPos.ofFloored(from);
        BlockPos srcPos = BlockPos.ofFloored(to);
        BlockPos prev = null;
        int solid = 0;

        for (int i = 1; i < steps; i++) {
            double t = (double) i / steps;
            BlockPos bp = BlockPos.ofFloored(from.lerp(to, t));
            if (bp.equals(prev)) {
                continue;
            }
            prev = bp;
            // Bỏ qua khối chứa nguồn âm (vd: tiếng đặt khối) và khối đứng của người chơi
            if (bp.equals(srcPos) || bp.equals(earPos)) {
                continue;
            }
            BlockState state = world.getBlockState(bp);
            if (!state.getCollisionShape(world, bp).isEmpty()) {
                solid++;
            }
        }
        return solid;
    }
}
